package structures;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class ScapegoatTree<T extends Comparable<T>> extends BinarySearchTree<T> {
  private int upperBound;


  @Override
  public void add(T t) throws NullPointerException {
    if (t == null) {
      throw new NullPointerException();
    }
    upperBound++;
    BSTNode<T> newNode = new BSTNode<T>(t, null, null);
    addToSubtreeNew(root, newNode);
    if(height() > (Math.log10(upperBound) / Math.log10(3.0/2.0)))
    {
      Queue<T> queue = new LinkedList<>();
      BSTNode<T> scapeGoat = newNode.getParent();
      BSTNode<T> goatChild = newNode;
      while( !(subtreeSize(goatChild) / (subtreeSize(scapeGoat)*1.0)  > (2.0/3.0) ) )
      {
        queue.add(goatChild.getData());
        goatChild = scapeGoat;
        scapeGoat = scapeGoat.getParent();
      }
      queue.add(goatChild.getData());
      queue.add(scapeGoat.getData());
      Iterator<T> queueIter = queue.iterator();
      ScapegoatTree<T> subTree = new ScapegoatTree<>();
      while(queueIter.hasNext())
      {
        subTree.addToSubtreeNew(subTree.getRoot(), new BSTNode<T>(queueIter.next(), null, null));
      }
      subTree.balance();

      BSTNode<T> parent = scapeGoat.getParent();
      if(scapeGoat.getParent().getLeft() == scapeGoat)
      {
        scapeGoat.getParent().setLeft(subTree.getRoot());
      }
      else
      {
        scapeGoat.getParent().setRight(subTree.getRoot());
      }
      subTree.getRoot().setParent(parent);
    }
  }

  protected void addToSubtreeNew(BSTNode<T> node, BSTNode<T> toAdd)
  {
    if (node == null) {
      root = toAdd;
      return;
    }
    BSTNode<T> currNode = node;
    BSTNode<T> prevNode = currNode.getParent();
    while(currNode != null)
    {
      if(toAdd.getData().compareTo(currNode.getData()) <= 0)
      {
        prevNode = currNode;
        currNode = currNode.getLeft();
      }
      else
      {
        prevNode = currNode;
        currNode = currNode.getRight();
      }
    }
    if(toAdd.getData().compareTo(prevNode.getData()) <= 0)
    {
      prevNode.setLeft(toAdd);
      toAdd.setParent(prevNode);
    }
    else
    {
      prevNode.setRight(toAdd);
      toAdd.setParent(prevNode);
    }
  }

  @Override
  public boolean remove(T element) throws NullPointerException {
    if (element == null) {
      throw new NullPointerException();
    }
    boolean done = super.remove(element);
    if(upperBound > 2*size())
    {
      balance();
      upperBound = size();
    }
    return done;
  }

  public static void main(String[] args) {
    BSTInterface<String> tree = new ScapegoatTree<String>();
    /*
    You can test your Scapegoat tree here.
    for (String r : new String[] {"0", "1", "2", "3", "4"}) {
      tree.add(r);
      System.out.println(toDotFormat(tree.getRoot()));
    }
    */
  }
}
