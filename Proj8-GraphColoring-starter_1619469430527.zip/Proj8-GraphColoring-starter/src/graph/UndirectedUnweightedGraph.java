package graph;
import java.util.ArrayList;
/**
 * This class implements general operations on a graph as specified by UndirectedGraphADT.
 * It implements a graph where data is contained in Vertex class instances.
 * Edges between verticies are unweighted and undirected.
 * A graph coloring algorithm determines the chromatic number. 
 * Colors are represented by integers. 
 * The maximum number of vertices and colors must be specified when the graph is instantiated.
 * You may implement the graph in the manner you choose. See instructions and course material for background.
 */
 
 public class UndirectedUnweightedGraph<T> implements UndirectedGraphADT<T> {
   // private class variables here.
   
   private int MAX_VERTICES;
   private int MAX_COLORS;
   private ArrayList<Vertex<T>> vertices;
   private boolean[][] table;
   private int vertexCount;
   private int edgeCount;
   private boolean[] colors;

   /**
    * Initialize all class variables and data structures. 
   */   
   public UndirectedUnweightedGraph (int maxVertices, int maxColors){
      MAX_VERTICES = maxVertices;
      MAX_COLORS = maxColors; 
      table = new boolean[MAX_VERTICES][MAX_VERTICES];
      colors = new boolean[maxColors];
      vertices = new ArrayList<Vertex<T>>();
      vertexCount = 0;
      edgeCount = 0;
     // TODO: Implement the rest of this method.

   }

   /**
    * Add a vertex containing this data to the graph.
    * Throws Exception if trying to add more than the max number of vertices.
   */
   public void addVertex(T data) throws Exception {
    if(vertexCount == MAX_VERTICES)
      throw new Exception();
    vertices.add(new Vertex<T>(data));
    vertexCount++;
   }
   
   /**
    * Return true if the graph contains a vertex with this data, false otherwise.
   */   
   public boolean hasVertex(T data){
    for(Vertex<T> e : vertices)
    {
      if(e.getData().equals(data))
        return true;
    }
    return false;
   } 

   /**
    * Add an edge between the vertices that contain these data.
    * Throws Exception if one or both vertices do not exist.
   */   
   public void addEdge(T data1, T data2) throws Exception{
    if(!(hasVertex(data1) && hasVertex(data2)))
      throw new Exception();
    table[getIndexFromData(data1)][getIndexFromData(data2)] = true;
    table[getIndexFromData(data2)][getIndexFromData(data1)] = true;
    edgeCount++;
   }
   private int getIndexFromData(T data)
   {
      for(Vertex<T> e : vertices)
      {
        if(e.getData().equals(data))
          return vertices.indexOf(e);
      }
      return -1;
   }

   /**
    * Get an ArrayList of the data contained in all vertices adjacent to the vertex that
    * contains the data passed in. Returns an ArrayList of zero length if no adjacencies exist in the graph.
    * Throws Exception if a vertex containing the data passed in does not exist.
   */   
   public ArrayList<T> getAdjacentData(T data) throws Exception{
      if(!(hasVertex(data)))
        throw new Exception();
      ArrayList<T> list = new ArrayList<>();
      for(Vertex<T> v : getAdjacentVertices(vertices.get(getIndexFromData(data))))
      {
        list.add(v.getData());
      }
      return list;
   }
   private ArrayList<Vertex<T>> getAdjacentVertices(Vertex<T> v)
   {
     ArrayList<Vertex<T>> vertexList = new ArrayList<>();
     for(int i = 0; i < table.length; i++)
     {
       if(i == getIndexFromData(v.getData()))
        continue;
       else if(table[getIndexFromData(v.getData())][i] == true)
        vertexList.add(vertices.get(i));
     }
     return vertexList;
   }
   
   /**
    * Returns the total number of vertices in the graph.
   */   
   public int getNumVertices(){
      return vertexCount;
   }

   /**
    * Returns the total number of edges in the graph.
   */   
   public int getNumEdges(){
      return edgeCount;
   }

   /**
    * Returns the minimum number of colors required for this graph as 
    * determined by a graph coloring algorithm.
    * Throws an Exception if more than the maximum number of colors are required
    * to color this graph.
   */   
   public int getChromaticNumber() throws Exception{
     for(Vertex<T> v : vertices)
     {
       if(v.getColor() != -1)
        colors[v.getColor()] = true;
       else
       {
         int colorToUse = getColorToUse(v);
         v.setColor(colorToUse);
         colors[colorToUse] = true;
       }
     }
     return countUsedColors();
   }
   private int countUsedColors()
   {
     int count = 0;
     for(int i = 0; i < colors.length; i++)
     {
       if(colors[i] == true)
        count++;
     }
     return count;
   }
   private int getColorToUse(Vertex<T> v) throws Exception
   {
     int colorToUse = -1;
     boolean[] adjColorsUsed = new boolean[MAX_COLORS];
     ArrayList<Vertex<T>> adjVertsList = getAdjacentVertices(v);
     for(Vertex<T> vert : adjVertsList)
     {
       if(vert.getColor() != -1)
        adjColorsUsed[vert.getColor()] = true;
     }
     for(int i = 0; i < adjColorsUsed.length; i++)
     {
       if(adjColorsUsed[i] == false)
       {
         return i;
       }
     }
     throw new Exception();
   }
   
}