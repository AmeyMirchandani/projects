package priorityqueue;

import java.util.Comparator;

//import jdk.nashorn.internal.runtime.arrays.NumericElements;

public class Heap<T> implements PriorityQueueADT<T> {

  private int numElements;
  private T[] heap;
  private boolean isMaxHeap;
  private Comparator<T> comparator;
  private final static int INIT_SIZE = 5;

  /**
   * Constructor for the heap.
   * @param comparator comparator object to define a sorting order for the heap elements.
   * @param isMaxHeap Flag to set if the heap should be a max heap or a min heap.
   */
  public Heap(Comparator<T> comparator, boolean isMaxHeap) {
      this.comparator = comparator;
      this.isMaxHeap = isMaxHeap;
      heap = (T[]) new Object[INIT_SIZE];
      numElements = 0;
  }
  
  private int getLeftChild(int parentIndex)
  {
    return (2*parentIndex)+1;
  }
  private int getRightChild(int parentIndex)
  {
    return (2*parentIndex)+2;
  }
  private int getParent(int childIndex)
  {
    return (childIndex-1)/2;
  }
  private void swap(int index1, int index2)
  {
    T elem1 = heap[index1];
    heap[index1] = heap[index2];
    heap[index2] = elem1;
  }
  private void expandCapacity()
  {
    T[] newHeap = (T[]) new Object[heap.length * 2];
    for(int i = 0; i < heap.length; i++)
    {
      newHeap[i] = heap[i];
    }
    heap = newHeap;
  }

  /**
   * This results in the entry at the specified index "bubbling up" to a location
   * such that the property of the heap are maintained. This method should run in
   * O(log(size)) time.
   * Note: When enqueue is called, an entry is placed at the next available index in 
   * the array and then this method is called on that index. 
   *
   * @param index the index to bubble up
   */
  public void bubbleUp(int index) {
      if(index == 0)
        return;
      else
      {
        if(compare(heap[index], heap[getParent(index)]) > 0)
        {
          swap(index, getParent(index));
          bubbleUp(getParent(index));
        }
        else
          return;
      }
  }

  /**
   * This method results in the entry at the specified index "bubbling down" to a
   * location such that the property of the heap are maintained. This method
   * should run in O(log(size)) time.
   * Note: When remove is called, if there are elements remaining in this
   *  the bottom most element of the heap is placed at
   * the 0th index and bubbleDown(0) is called.
   * 
   * @param index
   */
  public void bubbleDown(int index) {
      int maxIndex;
      if(getLeftChild(index)+1 > numElements && getRightChild(index)+1 > numElements) //no children
        return;
      else if(getRightChild(index)+1 > numElements)//no right child
      {
        if(compare(heap[index], heap[getLeftChild(index)]) < 0)
          maxIndex = getLeftChild(index);
        else
          return;
      }
      else if(getLeftChild(index)+1 > numElements)//no left child
      {
        if(compare(heap[index], heap[getRightChild(index)]) < 0)
          maxIndex = getRightChild(index);
        else
          return;
      }
      else//both children
      {
        if(compare(heap[index], heap[getRightChild(index)]) < 0 || compare(heap[index], heap[getLeftChild(index)]) < 0)
        {
          if(compare(heap[getLeftChild(index)], heap[getRightChild(index)]) > 0)
            maxIndex = getLeftChild(index);
          else
            maxIndex = getRightChild(index);
        }
        else
          return;
      }
      swap(index, maxIndex);
      bubbleDown(maxIndex);
  }

  /**
   * Test for if the queue is empty.
   * @return true if queue is empty, false otherwise.
   */
  public boolean isEmpty() {
    if(numElements == 0)
      return true;
    return false;
  }

  /**
   * Number of data elements in the queue.
   * @return the size
   */
  public int size(){
    return numElements;
  }

  /**
   * Compare method to implement max/min heap behavior.  It calls the comparae method from the 
   * comparator object and multiply its output by 1 and -1 if max and min heap respectively.
   * TODO: implement the heap compare method
   * @param element1 first element to be compared
   * @param element2 second element to be compared
   * @return positive int if {@code element1 > element2}, 0 if {@code element1 == element2}, negative int otherwise
   */
  public int compare(T element1 , T element2) {
    int result = 0;
    int compareSign =  -1;
    if (isMaxHeap) {
      compareSign = 1;
    }
    result = compareSign * comparator.compare(element1, element2);
    return result;
  }

  /**
   * Return the element with highest (or lowest if min heap) priority in the heap 
   * without removing the element.
   * @return T, the top element
   * @throws QueueUnderflowException if empty
   */
  public T peek() throws QueueUnderflowException {
    if(isEmpty())
      throw new QueueUnderflowException();
    return heap[0];
  }  

  /**
   * Removes and returns the element with highest (or lowest if min heap) priority in the heap.
   * @return T, the top element
   * @throws QueueUnderflowException if empty
   */
  public T dequeue() throws QueueUnderflowException{
    if(isEmpty())
      throw new QueueUnderflowException();
    T data;
    if(numElements == 1)
    {
      data = heap[0];
      heap[0] = null;
      numElements--;
    }
    else
    {
      data = heap[0];
      swap(0, numElements-1);
      heap[numElements-1] = null;
      numElements--;
      bubbleDown(0);
    }
    return data;
  }

  /**
   * Enqueue the element.
   * @param the new element
   */
  public void enqueue(T newElement) {
      if(numElements == heap.length)
        expandCapacity();
      heap[numElements] = newElement;
      bubbleUp(numElements);
      numElements++;
  }


}